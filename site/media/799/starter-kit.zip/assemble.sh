mkdir listing/
mkdir bin/
FILE=$1
mono tools/Organic.exe $1 bin/${FILE%.*}.bin --listing listing/${FILE%.*}.lst --json listing/${FILE%.*}.json --include extras/