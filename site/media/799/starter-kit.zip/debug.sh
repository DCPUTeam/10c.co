#!/bin/sh
FILE=$1
mono tools/Lettuce.exe bin/${FILE%.*}.bin listing/${FILE%.*}.lst --connect lem1802,GenericKeyboard,GenericClock,M35FD