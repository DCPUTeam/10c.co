#include "ext/screen.h"
#include "stdlib.h"
#include "itoa.h"

void sped3_setup(void* pointer, unsigned int count)
{
    __asm
    {
        SET PUSH, Y ; Preserve stack pointer

        .IMPORT _stubapi_locate_device
        SET A, 0x42ba ; Set the SPED3 ID (0x42babf3c)
        SET B, 0xbf3c 
        JSR [_stubapi_locate_device] ; Call the `locate_device` system function

        SET PUSH, A ; Keep the value returned by locate_device
        SET A, 0x1 ; Tell the SPED-3 where our vertices are
        SET X, <pointer>
        SET Y, <count>
        HWI POP ; Interrupt the SPED-3

        SET Y, POP
    }
}

void sped3_rotate(unsigned int alpha)
{
    __asm
    {
        SET PUSH, Y

        .IMPORT _stubapi_locate_device
        SET A, 0x42ba
        SET B, 0xbf3c
        JSR [_stubapi_locate_device]

        SET PUSH, A
        SET A, 0x2
        SET X, <alpha>
        HWI POP

        SET Y, POP
    }
}

void nop()
{
    __asm
    {
        SET PC, PC
    }
}

void rotate()
{
    int i;
    int j; 

    for(i = 0; i < 360; i++)
    {
        sped3_rotate(i);

        for(j = 0; j < 50; j++)
        {
            nop();
        }
       
        print_number(i, 0x8050); 
    }

    for(i = 0x8050; i < 0x8050 + 0x4; i++)
    {
        *i = 0;
    }
}

void main()
{
    unsigned int idx = 0;
    void* vertices = 0x5000;
  
    /* top */
    vertices[idx++] = 0x0000;
    vertices[idx++] = 0x02ff;

    vertices[idx++] = 0xff00;
    vertices[idx++] = 0x02ff;
    
    vertices[idx++] = 0xffff;
    vertices[idx++] = 0x02ff;

    vertices[idx++] = 0x00ff;
    vertices[idx++] = 0x02ff;

    /* bottom */
    vertices[idx++] = 0x0000;
    vertices[idx++] = 0x0200;
    
    vertices[idx++] = 0x00ff;
    vertices[idx++] = 0x0200;

    vertices[idx++] = 0xffff;
    vertices[idx++] = 0x0200;
    
    vertices[idx++] = 0xff00;
    vertices[idx++] = 0x0200;

    sped3_setup(vertices, 8);
    eputs("Setup done!", 0, 0);
    eputs("Rotation angle: ", 0, 2);

    while(1)
    {
        rotate();
    }
}
