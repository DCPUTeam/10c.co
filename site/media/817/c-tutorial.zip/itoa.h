void print_number(unsigned int number, void* scrn_addr)
{
	if (number == 0)
	{
		*(scrn_addr+1) = 48 + 0xC000;
		return 0;
	}
	
	unsigned int tmp = number;
	unsigned int length = 0;
	while(tmp > 0)
	{
		length++;
		tmp /= 10;
	}

	scrn_addr += length;
	char digit = length;
	
	while(number > 0)
	{
		digit = number % 10;
		number /= 10;

		*(scrn_addr) = digit + 48 + 0xC000;
		scrn_addr--;
	}
}


